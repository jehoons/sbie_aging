### R code from vignette source 'timeClip.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: style
###################################################
BiocStyle::latex()


###################################################
### code chunk number 2: cppr
###################################################
options(keep.source = TRUE, width = 60)
cppr <- packageDescription("timeClip")


###################################################
### code chunk number 3: loadData
###################################################
library(timeClip)
data(hif)
dim(hifExpression)


###################################################
### code chunk number 4: CollectTimepoints
###################################################
times <- as.numeric(colnames(hifExpression))


###################################################
### code chunk number 5: pathwayTimeCourseUsage
###################################################
library(timeClip)
pathwayAnalysis <- pathwayTimeCourse(hifExpression, times, hifGraph, npc=1, eqids=c(2,3,4,6,8,10,12,14,16,18,19,20,21,22))
pathwayAnalysis


###################################################
### code chunk number 6: timeClipUsage
###################################################
timeClipped <- timeClipSpaced(hifExpression, times, hifGraph, npc=1, eqids=c(2,3,4,6,8,10,12,14,16,18,19,20,21,22))
timeClipped$clipped[,1:5]


###################################################
### code chunk number 7: sintetizeYourResult
###################################################
clipped <- prunePaths(timeClipped$clipped, thr=0.2)
clipped[,1:5]


