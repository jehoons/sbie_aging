library(gRbase)
library(rrcov)

simulateDataMatrix <- function(timeSeries, numberOfGenes=10, numberOfTimeDependentGenes=1) {
    set.seed(14)
    
    if (numberOfTimeDependentGenes > numberOfGenes)
        stop("The number of time dependent genes must be smaller than equal to the number of genes.")
  
    timeData <- rmvnorm(numberOfGenes,rep(0,length(timeSeries)))
    
    timeDependentGenes <- sample(1:numberOfGenes,numberOfTimeDependentGenes)
    
    for (j in timeDependentGenes){
        ## model followed:
        ## y = intercept + slope(x) + rError
        
        intercept <- rnorm(1, 0, 1)
        slope <- -9
        rError <- rnorm(length(timeSeries), 0, 2)
        timeData[j,] <- intercept + rnorm(1, slope, 1) * timeSeries + rError
    }
    return(timeData)
}

ma <- simulateDataMatrix(1:10, 10, 0)
time <- 1:10

graph <- dag(c("me","ve"),c("me","al"),c("ve","al"),c("al","an"),c("al","st"),c("an","st"), c("an","tt"), c("tt","xt"), c("xt","yzf"), c("xt","r6"), c("sp","r6"))
row.names(ma) <- nodes(graph)
colnames(ma) <- time

pte <- pathwayTimeCourseEqui(ma, time, graph, 1, FALSE)

test_timeClipEqually <- function(){
  set.seed(1234)  
  checkEqualsNumeric(3, length(pte))
  checkTrue(pte$alpha > 0.05)
  checkException(pathwayTimeCourseEqui(ma, 1:9, graph, 1, FALSE))
}
