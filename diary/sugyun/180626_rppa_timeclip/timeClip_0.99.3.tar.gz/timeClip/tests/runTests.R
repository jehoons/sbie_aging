BiocGenerics:::testPackage("clipper")

pattern="^test_.*\\.R$"
