import numpy as np
import pandas as pd
import phenotype_detector as phd
f = open('b5-simul-log_v2.txt', 'r')
attractor_deter_list = ['caspase3','RB1','E2F','LC','mTOR']  # RB1 => pRB1 in log_v1.txt
logic_table = np.array([
                        ['0', '0', '1', 'none', '1', 'Pro'],
                        ['1', 'none', 'none', 'none', 'none', 'Apop'],
                        ['0', '1', '0', 'none', '0', 'Qui'],
                        ['0', '1', '0', '1', '1', 'Qui'],
                        ['0', '1', '0', '0', '1', 'Sen']
                        ])

result = phd.phenotype_detector(f,attractor_deter_list,logic_table)