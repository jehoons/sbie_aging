def attractor(file, attractor_deter_list):
    dic_result = {}
    for n, line in enumerate(file):
        line = line.strip()
        if not line:
            continue
        elif line.startswith('input_condition'):
            lownuex = line.split()[2][0:-1]  # LowNuEx
            IGF1 = line.split()[4][0:-1]  # IGF1
            continue
        elif line.startswith('type'):
            result_line = []
            result_line.append(lownuex)  # LowNuEx
            result_line.append(IGF1)  # IGF1
            result_line.append(line.split()[1])  # type
            result_line.append(line.split()[3])  # ratio
            continue
        elif line.startswith('sign'):
            protein_name_list = line.split(',')
            protein_name_list = protein_name_list[1:]
            index = []
            for i in attractor_deter_list:
                index.append(protein_name_list.index(i))  # get the index of attractor_deter_protein
            continue
        list_line = line.split(',')
        list_line = list_line[1:]
        if ('0' in list_line or '1' in list_line):
            state_rev = ''
            for i in index:
                state_rev += list_line[i]
            dic_result[n] = result_line +[state_rev]
    return dic_result