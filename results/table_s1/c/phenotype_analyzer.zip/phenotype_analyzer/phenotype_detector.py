import attractor_phenotype as ap
def phenotype_detector(file, attractor_deter_list, logic_table):
    dic_result = ap.attractor(file, attractor_deter_list)
    for i in logic_table:
        index = []
        check_series = ''
        for n, m in enumerate(i):
            if m != 'none':
                index.append(n)
                if len(m) < 2:
                    check_series = check_series + m
        index = index[:-1]
        for j in dic_result:
            ch = dic_result[j][4]
            target_series = ''
            for n in index:
                target_series = target_series + ch[n]
            if target_series == check_series:
                dic_result[j].append(i[-1])

    g = open('b5-updated1-boolsim-results-summary_phenotype_v2.txt', 'w')
    g.write('LowNuEx    IGF1    type    ratio   attractor   phenotyppe\n')
    for i in dic_result:
        for j in dic_result[i]:
            g.write("%s\t" %(j))
        g.write('\n')
    print('file is saved!')
    return 0
